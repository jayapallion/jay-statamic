<?php return array (
  'ajthinking/archetype' => 
  array (
    'providers' => 
    array (
      0 => 'Archetype\\ServiceProvider',
    ),
    'dont-discover' => 
    array (
    ),
  ),
  'datascaled/statamic-fathom-stats' => 
  array (
    'providers' => 
    array (
      0 => 'Datascaled\\FathomStats\\ServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'rebing/graphql-laravel' => 
  array (
    'aliases' => 
    array (
      'GraphQL' => 'Rebing\\GraphQL\\Support\\Facades\\GraphQL',
    ),
    'providers' => 
    array (
      0 => 'Rebing\\GraphQL\\GraphQLServiceProvider',
    ),
  ),
  'statamic/cms' => 
  array (
    'aliases' => 
    array (
      'Statamic' => 'Statamic\\Statamic',
    ),
    'providers' => 
    array (
      0 => 'Statamic\\Providers\\StatamicServiceProvider',
    ),
  ),
  'stillat/blade-parser' => 
  array (
    'providers' => 
    array (
      0 => 'Stillat\\BladeParser\\ServiceProvider',
      1 => 'Stillat\\BladeParser\\Providers\\ValidatorServiceProvider',
    ),
  ),
  'wilderborn/partyline' => 
  array (
    'aliases' => 
    array (
      'Partyline' => 'Wilderborn\\Partyline\\Facade',
    ),
    'providers' => 
    array (
      0 => 'Wilderborn\\Partyline\\ServiceProvider',
    ),
  ),
);