<?php return array (
  'datascaled/statamic-fathom-stats' => 
  array (
    'id' => 'datascaled/statamic-fathom-stats',
    'slug' => NULL,
    'editions' => 
    array (
    ),
    'marketplaceId' => 666,
    'marketplaceSlug' => 'fathom-stats',
    'marketplaceUrl' => 'https://statamic.com/addons/datascale/fathom-stats',
    'marketplaceSellerSlug' => 'datascale',
    'isCommercial' => false,
    'latestVersion' => '1.0.0',
    'version' => '1.0.5',
    'namespace' => 'Datascaled\\FathomStats',
    'autoload' => 'src/',
    'provider' => 'Datascaled\\FathomStats\\ServiceProvider',
    'name' => 'Statamic Fathom Stats',
    'url' => NULL,
    'description' => 'Statamic Fathom Stats addon',
    'developer' => NULL,
    'developerUrl' => NULL,
    'email' => NULL,
  ),
);