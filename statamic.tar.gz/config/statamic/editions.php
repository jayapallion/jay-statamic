<?php

return [

    'pro' => env('STATAMIC_PRO_ENABLED', false),

    'addons' => [
        //
    ],

];
