---
id: home
blueprint: pages
title: Home
template: home
author: 5a99e6b0-407b-43f3-9976-ed242aa2448e
updated_by: 5a99e6b0-407b-43f3-9976-ed242aa2448e
updated_at: 1744123942
sections:
  -
    id: m98lgtml
    title: 'Deploy to the cloud with confidence'
    hero_subtitle: 'Design, send and automate interactive emails to boost your email conversions by 3x'
    button_text: 'Get started'
    button_link: 'https://app.sendx.io'
    type: hero
    enabled: true
    hero_title: 'Email marketing made easy'
---
